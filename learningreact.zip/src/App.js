
import './App.css';
import Cart from './Cart'

function App() {
    return ( <div className = "App" >
        <h1>cart</h1>
        <div className="arrange">
        <Cart/>
     
        </div>
        
</div >
    );
}

export default App;