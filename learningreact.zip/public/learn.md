Node modules: all third party packages present  here

index.js is the entry point of react<!--  -->
package.json : contains all meta information about  Project


FLOW OF APP :
    local host:3000 -> index.html -> index.js(ENTRY POINT) ->App.js ->  UI
